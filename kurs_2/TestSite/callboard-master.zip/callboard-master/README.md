# CallBoard (Доска объявлений) on [Django 2](https://github.com/django/django) and [Svelte](https://github.com/sveltejs/svelte)


- Python => 3.7.3
- Django => 2
- Postgres == 10
- Svelte == 3

**Установка:**

- pip install -r req.txt
- cd frontend
- npm install

**Develop**


**Команды**
- Создание файлов миграций
-- python manage.py makemigrations
- Применение миграций
-- python manage.py migrate
- Создание супер пользователя
-- python manage.py createsuperuser




