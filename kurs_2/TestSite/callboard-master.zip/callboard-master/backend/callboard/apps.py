from django.apps import AppConfig


class CallboardConfig(AppConfig):
    name = 'callboard'
